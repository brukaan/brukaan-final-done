# Brukaan Designers & Associates — static website

A plain static site (no database, no login, no server). `npm run build` produces a folder called `out/`
that any host can serve.

## Easiest: upload the prebuilt folder
Use the separate **brukaan-site-ready-to-upload.zip** (it is just the finished `out/` folder).
- **Cloudflare Pages:** Workers & Pages → Create → Pages → *Upload assets* → drop the unzipped folder.
- **Netlify:** app.netlify.com/drop → drag the unzipped folder.
- **Any web host:** upload the folder's contents to `public_html`.

## Deploy from GitHub (auto-updates when you push)
Build command: `npm run build` (or `pnpm build`)

| Host | Setting |
|---|---|
| **Cloudflare (Workers Builds)** | Deploy command: `npx wrangler deploy` — already configured by `wrangler.jsonc` |
| **Cloudflare Pages** | Build output directory: `out` (leave deploy command empty) |
| **Netlify** | Publish directory: `out` |
| **Vercel** | Framework: Next.js — nothing else needed |

## Editing content
- Text, contact details, services, projects: `lib/site-config.ts`
- Gallery photos: put images in `public/gallery/` (and a smaller copy in `public/gallery/thumbs/`), then list them in `lib/gallery-seed.ts`
- Project photos: set `coverImage` and `gallery` for each project in `lib/site-config.ts`
- Then run `npm run build` again and redeploy.

## Contact form
No server needed: the form opens WhatsApp or the visitor's email app with the enquiry pre-filled.
(To receive enquiries silently instead, add a form service such as Formspree later.)
