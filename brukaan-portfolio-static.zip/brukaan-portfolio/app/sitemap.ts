import type { MetadataRoute } from 'next'
import { getProjects, SITE_URL } from '@/lib/data'

export const dynamic = 'force-static'
export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const projects = await getProjects()
  return [
    { url: SITE_URL, priority: 1 },
    { url: `${SITE_URL}/gallery/`, priority: 0.8 },
    ...projects.map((p) => ({ url: `${SITE_URL}/projects/${p.slug}/`, priority: 0.6 })),
  ]
}
