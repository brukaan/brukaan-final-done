import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import { ArrowUpRight } from 'lucide-react'
import { getProject, getProjects, getSettings } from '@/lib/data'
import { SiteHeader } from '@/components/site/header'
import { SiteFooter } from '@/components/site/footer'
import { WhatsAppFloat } from '@/components/site/whatsapp-float'

export const dynamicParams = false
export async function generateStaticParams() {
  return (await getProjects()).map((p) => ({ slug: p.slug }))
}
type Props = { params: Promise<{ slug: string }> }

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const p = await getProject((await params).slug)
  if (!p) return { title: 'Project not found' }
  return { title: p.title, description: p.shortDescription || `${p.title} — ${p.type} by Brukaan Designers & Associates.`, alternates: { canonical: `/projects/${p.slug}` }, openGraph: p.coverImage ? { images: [p.coverImage] } : undefined }
}

export default async function ProjectPage({ params }: Props) {
  const { slug } = await params
  const [project, all, s] = await Promise.all([getProject(slug), getProjects(), getSettings()])
  if (!project) notFound()
  const i = all.findIndex((x) => x.slug === slug), next = all[(i + 1) % all.length]
  const meta: [string, string][] = ([['Type', project.type], ['Status', project.status], ['Location', project.location], ['Year', project.year], ['Area', project.area]] as [string, string][]).filter(([, v]) => v)

  return (
    <main>
      <SiteHeader firmName={s.firmName} logoUrl={s.logoUrl} forceSolid />
      <div className="page-top">
        <a className="back" href="/#projects">← All projects</a>
        <p className="label">{project.type || 'Project'}</p>
        <h1>{project.title}</h1>
        {meta.length > 0 && <dl className="case-meta">{meta.map(([k, v]) => <div key={k}><dt>{k}</dt><dd>{v}</dd></div>)}</dl>}
      </div>

      {project.coverImage && <img className="case-cover" src={project.coverImage} alt={`${project.title} — cover`} />}

      {(project.shortDescription || project.concept || project.description) && (
        <section className="pad"><div className="container case-text">
          <div>{project.shortDescription && <p className="lead">{project.shortDescription}</p>}</div>
          <div>
            {project.concept && <><h2>Design concept</h2><p>{project.concept}</p></>}
            {project.description && <><h2>Approach</h2><p>{project.description}</p></>}
            {project.mapsUrl && <a className="link" href={project.mapsUrl} target="_blank" rel="noopener noreferrer">View location <ArrowUpRight size={14} /></a>}
          </div>
        </div></section>
      )}

      {project.gallery.length > 0 ? (
        <section style={{ padding: '0 var(--pad) 100px' }}><div className="container case-gallery">{project.gallery.map((src) => <img key={src} src={src} alt={`${project.title} gallery`} loading="lazy" />)}</div></section>
      ) : !project.coverImage && (
        <section style={{ padding: '0 var(--pad) 100px' }}><div className="container empty-note">Photography for this project is coming soon. <a className="link" href="/gallery" style={{ marginLeft: 12 }}>Browse the portfolio</a></div></section>
      )}

      <section className="dark pad" style={{ textAlign: 'center' }}>
        <h2 style={{ marginBottom: 32 }}>Discuss a similar <em>project.</em></h2>
        <a className="btn btn-solid" href="/#contact">Contact the studio <ArrowUpRight size={15} /></a>
        {next && next.slug !== slug && <p style={{ marginTop: 64 }}><a className="link" href={`/projects/${next.slug}`}>Next: {next.title} <ArrowUpRight size={14} /></a></p>}
      </section>
      <SiteFooter s={s} />
      <WhatsAppFloat number={s.whatsapp} />
    </main>
  )
}
