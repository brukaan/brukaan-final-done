'use client'

import { FormEvent, useRef, useState } from 'react'
import { ArrowUpRight } from 'lucide-react'

const TYPES = ['Architecture', 'Interior Design', 'Vastu Consultancy', 'Landscaping', 'Urban Planning', 'Project Management', 'Other']

/** No backend: the enquiry opens WhatsApp or the visitor's email app, pre-filled. */
export function ContactForm({ whatsapp, email }: { whatsapp?: string; email?: string }) {
  const ref = useRef<HTMLFormElement>(null)
  const [error, setError] = useState('')

  function compose() {
    const f = ref.current!
    if (!f.reportValidity()) return null
    const v = (n: string) => String((f.elements.namedItem(n) as HTMLInputElement)?.value || '').trim()
    const opt = (label: string, val: string): string | false => (val ? `${label}: ${val}` : false)
    const lines: (string | false)[] = [`Name: ${v('name')}`, `Email: ${v('email')}`, opt('Phone', v('phone')), opt('Project type', v('projectType')), opt('Location', v('location')), opt('Size / budget', v('sizeOrBudget')), '', v('message')]
    return { text: lines.filter((l) => l !== false).join('\n'), name: v('name') }
  }
  function viaWhatsApp() {
    const m = compose(); if (!m) return
    setError(''); window.open(`https://wa.me/${whatsapp}?text=${encodeURIComponent('Hello Brukaan, I would like to discuss a project.\n\n' + m.text)}`, '_blank', 'noopener')
  }
  function viaEmail(e?: FormEvent) {
    e?.preventDefault()
    const m = compose(); if (!m) return
    setError(''); window.location.href = `mailto:${email}?subject=${encodeURIComponent('Project enquiry from ' + m.name)}&body=${encodeURIComponent(m.text)}`
  }

  return (
    <form ref={ref} className="contact-form" onSubmit={viaEmail}>
      <label>Name *<input name="name" required autoComplete="name" placeholder="Your name" /></label>
      <label>Email *<input name="email" type="email" required autoComplete="email" placeholder="you@example.com" /></label>
      <label>Phone<input name="phone" type="tel" autoComplete="tel" placeholder="Optional" /></label>
      <label>Project type<select name="projectType" defaultValue=""><option value="">Select one</option>{TYPES.map((t) => <option key={t}>{t}</option>)}</select></label>
      <label>Location<input name="location" placeholder="Project location" /></label>
      <label>Approx. size / budget<input name="sizeOrBudget" placeholder="Optional" /></label>
      <label className="full">Tell us about your project *<textarea name="message" required minLength={10} rows={5} placeholder="Plot size, the spaces you imagine, timeline…" /></label>
      {whatsapp && <button type="button" className="btn btn-solid full" onClick={viaWhatsApp} style={{ justifyContent: 'center' }}>Send on WhatsApp <ArrowUpRight size={15} /></button>}
      {email && <button type="submit" className="btn full" style={{ justifyContent: 'center' }}>Send by email <ArrowUpRight size={15} /></button>}
      {error && <p className="form-note full" role="alert">{error}</p>}
    </form>
  )
}
