import type { Settings } from '@/lib/data'

export function SiteFooter({ s }: { s: Settings }) {
  const socials = Object.entries(s.social).filter(([, v]) => v)
  return (
    <footer className="site-footer">
      <div className="footer-top">
        <div className="footer-brand">BRUKAAN<small>{s.tagline}</small></div>
        <div><h4>Explore</h4><a href="/#studio">Studio</a><a href="/#portfolio">Portfolio</a><a href="/#services">Services</a><a href="/#projects">Projects</a><a href="/#contact">Contact</a></div>
        <div><h4>Contact</h4>{s.email && <a href={`mailto:${s.email}`}>{s.email}</a>}{s.phone && <a href={`tel:${s.phone}`}>{s.phone}</a>}{s.whatsapp && <a href={`https://wa.me/${s.whatsapp}`}>WhatsApp</a>}{s.businessHours && <p>{s.businessHours}</p>}</div>
        <div><h4>Follow</h4>{socials.length ? socials.map(([k, v]) => <a key={k} href={v} target="_blank" rel="noopener noreferrer" style={{ textTransform: 'capitalize' }}>{k}</a>) : <p>—</p>}</div>
      </div>
      <div className="footer-bottom"><span>© {new Date().getFullYear()} {s.firmName}. All rights reserved.</span><span>{s.serviceAreas}</span></div>
    </footer>
  )
}
