'use client'

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { ArrowUpRight, ChevronLeft, ChevronRight, X } from 'lucide-react'
import type { GalleryItem } from '@/lib/gallery-seed'

/** Round-robin across categories so a limited preview shows the full range of work. */
function mixed(items: GalleryItem[], n: number) {
  const groups = new Map<string, GalleryItem[]>()
  items.forEach((it) => groups.set(it.category, [...(groups.get(it.category) ?? []), it]))
  const lists = [...groups.values()], out: GalleryItem[] = []
  for (let r = 0; out.length < n && lists.some((l) => l[r]); r++) lists.forEach((l) => { if (l[r] && out.length < n) out.push(l[r]) })
  return out
}

export function Gallery({ items, categories, limit, showAllLink }: { items: GalleryItem[]; categories: Record<string, string>; limit?: number; showAllLink?: boolean }) {
  const [cat, setCat] = useState('all')
  const [open, setOpen] = useState<number | null>(null)

  const counts = useMemo(() => items.reduce<Record<string, number>>((a, it) => ({ ...a, [it.category]: (a[it.category] ?? 0) + 1 }), {}), [items])
  const tabs = Object.entries(categories).filter(([k]) => counts[k])
  const visible = useMemo(() => {
    if (cat !== 'all') return items.filter((i) => i.category === cat)
    return limit ? mixed(items, limit) : items
  }, [items, cat, limit])

  return (
    <div>
      <div className="filters" role="tablist" aria-label="Portfolio categories">
        <button role="tab" aria-selected={cat === 'all'} className={cat === 'all' ? 'active' : ''} onClick={() => setCat('all')}>All<sup>{items.length}</sup></button>
        {tabs.map(([k, label]) => <button key={k} role="tab" aria-selected={cat === k} className={cat === k ? 'active' : ''} onClick={() => setCat(k)}>{label}<sup>{counts[k]}</sup></button>)}
      </div>

      <div className="masonry">
        {visible.map((it, n) => (
          <button key={it.url} className="tile" onClick={() => setOpen(n)} aria-label={`Open ${it.title}`}
            style={it.width && it.height ? { aspectRatio: `${it.width} / ${it.height}` } : undefined}>
            <img src={it.thumbUrl || it.url} alt={it.caption || `${it.title} by Brukaan Designers`} loading="lazy" decoding="async" width={it.width ?? undefined} height={it.height ?? undefined} />
            <span className="cap">{categories[it.category] ?? it.category}</span>
          </button>
        ))}
      </div>

      {showAllLink && limit && cat === 'all' && items.length > limit && (
        <div className="more"><a className="btn" href="/gallery">View all {items.length} images <ArrowUpRight size={15} /></a></div>
      )}
      {open !== null && <Lightbox items={visible} start={open} categories={categories} onClose={() => setOpen(null)} />}
    </div>
  )
}

function Lightbox({ items, start, categories, onClose }: { items: GalleryItem[]; start: number; categories: Record<string, string>; onClose: () => void }) {
  const [i, setI] = useState(start)
  const touch = useRef<number | null>(null)
  const go = useCallback((d: number) => setI((n) => (n + d + items.length) % items.length), [items.length])

  useEffect(() => {
    const key = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); if (e.key === 'ArrowRight') go(1); if (e.key === 'ArrowLeft') go(-1) }
    window.addEventListener('keydown', key)
    const prev = document.body.style.overflow; document.body.style.overflow = 'hidden'
    return () => { window.removeEventListener('keydown', key); document.body.style.overflow = prev }
  }, [go, onClose])
  useEffect(() => { // warm the cache for neighbours
    ;[1, -1].forEach((d) => { const n = items[(i + d + items.length) % items.length]; if (n) new Image().src = n.url })
  }, [i, items])

  const it = items[i]
  return (
    <div className="lightbox" role="dialog" aria-modal="true" aria-label={it.title}
      onTouchStart={(e) => { touch.current = e.touches[0].clientX }}
      onTouchEnd={(e) => { if (touch.current === null) return; const dx = e.changedTouches[0].clientX - touch.current; if (Math.abs(dx) > 50) go(dx < 0 ? 1 : -1); touch.current = null }}>
      <div className="lb-top"><span>{categories[it.category] ?? it.category}</span><button className="lb-btn" onClick={onClose} aria-label="Close"><X size={20} /></button></div>
      <div className="lb-stage" onClick={(e) => { if (e.target === e.currentTarget) onClose() }}>
        <img key={it.url} src={it.url} alt={it.caption || it.title} />
        <button className="lb-btn lb-prev" onClick={() => go(-1)} aria-label="Previous"><ChevronLeft /></button>
        <button className="lb-btn lb-next" onClick={() => go(1)} aria-label="Next"><ChevronRight /></button>
      </div>
      <div className="lb-bottom"><span>{it.title}</span><span>{i + 1} / {items.length}</span></div>
    </div>
  )
}
