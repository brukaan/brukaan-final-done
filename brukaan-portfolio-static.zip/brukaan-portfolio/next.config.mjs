/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export',        // builds a plain static site into ./out
  trailingSlash: true,     // /gallery/ -> out/gallery/index.html (works on every static host)
  images: { unoptimized: true },
}
export default nextConfig
