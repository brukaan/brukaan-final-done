// Generated from the studio photo library (68 images). Used as the default
// gallery until media is managed from the admin panel.
export const galleryCategories = {"exteriors": "Residential Exteriors", "landscape": "Landscape & Courtyards", "living": "Living & Dining", "bedrooms": "Bedrooms", "kids": "Kids & Teens", "pooja": "Pooja Rooms", "leisure": "Leisure & Wellness", "details": "Workspaces & Details"} as Record<string, string>
export type GalleryCategory = keyof typeof galleryCategories

export type GalleryItem = {
  id?: number
  title: string
  category: string
  url: string
  thumbUrl?: string | null
  width?: number | null
  height?: number | null
  caption?: string | null
  sortOrder?: number
}

export const gallerySeed: GalleryItem[] = [
 {
  "title": "Residence exterior 01",
  "category": "exteriors",
  "url": "/gallery/exteriors-01.jpg",
  "thumbUrl": "/gallery/thumbs/exteriors-01.jpg",
  "width": 1600,
  "height": 1200,
  "sortOrder": 0
 },
 {
  "title": "Residence exterior 02",
  "category": "exteriors",
  "url": "/gallery/exteriors-02.jpg",
  "thumbUrl": "/gallery/thumbs/exteriors-02.jpg",
  "width": 1600,
  "height": 1200,
  "sortOrder": 1
 },
 {
  "title": "Residence exterior 03",
  "category": "exteriors",
  "url": "/gallery/exteriors-03.jpg",
  "thumbUrl": "/gallery/thumbs/exteriors-03.jpg",
  "width": 1600,
  "height": 1200,
  "sortOrder": 2
 },
 {
  "title": "Residence exterior 04",
  "category": "exteriors",
  "url": "/gallery/exteriors-04.jpg",
  "thumbUrl": "/gallery/thumbs/exteriors-04.jpg",
  "width": 1600,
  "height": 1219,
  "sortOrder": 3
 },
 {
  "title": "Residence exterior 05",
  "category": "exteriors",
  "url": "/gallery/exteriors-05.jpg",
  "thumbUrl": "/gallery/thumbs/exteriors-05.jpg",
  "width": 1600,
  "height": 1200,
  "sortOrder": 4
 },
 {
  "title": "Residence exterior 06",
  "category": "exteriors",
  "url": "/gallery/exteriors-06.jpg",
  "thumbUrl": "/gallery/thumbs/exteriors-06.jpg",
  "width": 1472,
  "height": 1600,
  "sortOrder": 5
 },
 {
  "title": "Residence exterior 07",
  "category": "exteriors",
  "url": "/gallery/exteriors-07.jpg",
  "thumbUrl": "/gallery/thumbs/exteriors-07.jpg",
  "width": 1600,
  "height": 1353,
  "sortOrder": 6
 },
 {
  "title": "Residence exterior 08",
  "category": "exteriors",
  "url": "/gallery/exteriors-08.jpg",
  "thumbUrl": "/gallery/thumbs/exteriors-08.jpg",
  "width": 1600,
  "height": 1150,
  "sortOrder": 7
 },
 {
  "title": "Residence exterior 09",
  "category": "exteriors",
  "url": "/gallery/exteriors-09.jpg",
  "thumbUrl": "/gallery/thumbs/exteriors-09.jpg",
  "width": 1131,
  "height": 1600,
  "sortOrder": 8
 },
 {
  "title": "Residence exterior 10",
  "category": "exteriors",
  "url": "/gallery/exteriors-10.jpg",
  "thumbUrl": "/gallery/thumbs/exteriors-10.jpg",
  "width": 1600,
  "height": 1051,
  "sortOrder": 9
 },
 {
  "title": "Residence exterior 11",
  "category": "exteriors",
  "url": "/gallery/exteriors-11.jpg",
  "thumbUrl": "/gallery/thumbs/exteriors-11.jpg",
  "width": 1600,
  "height": 1200,
  "sortOrder": 10
 },
 {
  "title": "Residence exterior 12",
  "category": "exteriors",
  "url": "/gallery/exteriors-12.jpg",
  "thumbUrl": "/gallery/thumbs/exteriors-12.jpg",
  "width": 1600,
  "height": 1150,
  "sortOrder": 11
 },
 {
  "title": "Residence exterior 13",
  "category": "exteriors",
  "url": "/gallery/exteriors-13.jpg",
  "thumbUrl": "/gallery/thumbs/exteriors-13.jpg",
  "width": 1600,
  "height": 1353,
  "sortOrder": 12
 },
 {
  "title": "Residence exterior 14",
  "category": "exteriors",
  "url": "/gallery/exteriors-14.jpg",
  "thumbUrl": "/gallery/thumbs/exteriors-14.jpg",
  "width": 1600,
  "height": 838,
  "sortOrder": 13
 },
 {
  "title": "Residence exterior 15",
  "category": "exteriors",
  "url": "/gallery/exteriors-15.jpg",
  "thumbUrl": "/gallery/thumbs/exteriors-15.jpg",
  "width": 1131,
  "height": 1600,
  "sortOrder": 14
 },
 {
  "title": "Residence exterior 16",
  "category": "exteriors",
  "url": "/gallery/exteriors-16.jpg",
  "thumbUrl": "/gallery/thumbs/exteriors-16.jpg",
  "width": 1024,
  "height": 717,
  "sortOrder": 15
 },
 {
  "title": "Residence exterior 17",
  "category": "exteriors",
  "url": "/gallery/exteriors-17.jpg",
  "thumbUrl": "/gallery/thumbs/exteriors-17.jpg",
  "width": 1280,
  "height": 896,
  "sortOrder": 16
 },
 {
  "title": "Landscape design 01",
  "category": "landscape",
  "url": "/gallery/landscape-01.jpg",
  "thumbUrl": "/gallery/thumbs/landscape-01.jpg",
  "width": 1600,
  "height": 899,
  "sortOrder": 17
 },
 {
  "title": "Landscape design 02",
  "category": "landscape",
  "url": "/gallery/landscape-02.jpg",
  "thumbUrl": "/gallery/thumbs/landscape-02.jpg",
  "width": 1600,
  "height": 899,
  "sortOrder": 18
 },
 {
  "title": "Landscape design 03",
  "category": "landscape",
  "url": "/gallery/landscape-03.jpg",
  "thumbUrl": "/gallery/thumbs/landscape-03.jpg",
  "width": 1600,
  "height": 920,
  "sortOrder": 19
 },
 {
  "title": "Landscape design 04",
  "category": "landscape",
  "url": "/gallery/landscape-04.jpg",
  "thumbUrl": "/gallery/thumbs/landscape-04.jpg",
  "width": 1600,
  "height": 920,
  "sortOrder": 20
 },
 {
  "title": "Landscape design 05",
  "category": "landscape",
  "url": "/gallery/landscape-05.jpg",
  "thumbUrl": "/gallery/thumbs/landscape-05.jpg",
  "width": 1600,
  "height": 899,
  "sortOrder": 21
 },
 {
  "title": "Landscape design 06",
  "category": "landscape",
  "url": "/gallery/landscape-06.jpg",
  "thumbUrl": "/gallery/thumbs/landscape-06.jpg",
  "width": 1600,
  "height": 872,
  "sortOrder": 22
 },
 {
  "title": "Landscape design 07",
  "category": "landscape",
  "url": "/gallery/landscape-07.jpg",
  "thumbUrl": "/gallery/thumbs/landscape-07.jpg",
  "width": 1600,
  "height": 872,
  "sortOrder": 23
 },
 {
  "title": "Landscape design 08",
  "category": "landscape",
  "url": "/gallery/landscape-08.jpg",
  "thumbUrl": "/gallery/thumbs/landscape-08.jpg",
  "width": 1600,
  "height": 920,
  "sortOrder": 24
 },
 {
  "title": "Landscape design 09",
  "category": "landscape",
  "url": "/gallery/landscape-09.jpg",
  "thumbUrl": "/gallery/thumbs/landscape-09.jpg",
  "width": 1600,
  "height": 872,
  "sortOrder": 25
 },
 {
  "title": "Landscape design 10",
  "category": "landscape",
  "url": "/gallery/landscape-10.jpg",
  "thumbUrl": "/gallery/thumbs/landscape-10.jpg",
  "width": 1600,
  "height": 872,
  "sortOrder": 26
 },
 {
  "title": "Living space 01",
  "category": "living",
  "url": "/gallery/living-01.jpg",
  "thumbUrl": "/gallery/thumbs/living-01.jpg",
  "width": 1600,
  "height": 960,
  "sortOrder": 27
 },
 {
  "title": "Living space 02",
  "category": "living",
  "url": "/gallery/living-02.jpg",
  "thumbUrl": "/gallery/thumbs/living-02.jpg",
  "width": 1600,
  "height": 960,
  "sortOrder": 28
 },
 {
  "title": "Living space 03",
  "category": "living",
  "url": "/gallery/living-03.jpg",
  "thumbUrl": "/gallery/thumbs/living-03.jpg",
  "width": 1600,
  "height": 949,
  "sortOrder": 29
 },
 {
  "title": "Living space 04",
  "category": "living",
  "url": "/gallery/living-04.jpg",
  "thumbUrl": "/gallery/thumbs/living-04.jpg",
  "width": 1600,
  "height": 900,
  "sortOrder": 30
 },
 {
  "title": "Living space 05",
  "category": "living",
  "url": "/gallery/living-05.jpg",
  "thumbUrl": "/gallery/thumbs/living-05.jpg",
  "width": 1600,
  "height": 900,
  "sortOrder": 31
 },
 {
  "title": "Living space 06",
  "category": "living",
  "url": "/gallery/living-06.jpg",
  "thumbUrl": "/gallery/thumbs/living-06.jpg",
  "width": 1600,
  "height": 900,
  "sortOrder": 32
 },
 {
  "title": "Living space 07",
  "category": "living",
  "url": "/gallery/living-07.jpg",
  "thumbUrl": "/gallery/thumbs/living-07.jpg",
  "width": 1600,
  "height": 900,
  "sortOrder": 33
 },
 {
  "title": "Living space 08",
  "category": "living",
  "url": "/gallery/living-08.jpg",
  "thumbUrl": "/gallery/thumbs/living-08.jpg",
  "width": 1600,
  "height": 900,
  "sortOrder": 34
 },
 {
  "title": "Bedroom 01",
  "category": "bedrooms",
  "url": "/gallery/bedrooms-01.jpg",
  "thumbUrl": "/gallery/thumbs/bedrooms-01.jpg",
  "width": 1600,
  "height": 933,
  "sortOrder": 35
 },
 {
  "title": "Bedroom 02",
  "category": "bedrooms",
  "url": "/gallery/bedrooms-02.jpg",
  "thumbUrl": "/gallery/thumbs/bedrooms-02.jpg",
  "width": 1600,
  "height": 900,
  "sortOrder": 36
 },
 {
  "title": "Bedroom 03",
  "category": "bedrooms",
  "url": "/gallery/bedrooms-03.jpg",
  "thumbUrl": "/gallery/thumbs/bedrooms-03.jpg",
  "width": 1600,
  "height": 900,
  "sortOrder": 37
 },
 {
  "title": "Bedroom 04",
  "category": "bedrooms",
  "url": "/gallery/bedrooms-04.jpg",
  "thumbUrl": "/gallery/thumbs/bedrooms-04.jpg",
  "width": 1600,
  "height": 1000,
  "sortOrder": 38
 },
 {
  "title": "Bedroom 05",
  "category": "bedrooms",
  "url": "/gallery/bedrooms-05.jpg",
  "thumbUrl": "/gallery/thumbs/bedrooms-05.jpg",
  "width": 1600,
  "height": 900,
  "sortOrder": 39
 },
 {
  "title": "Bedroom 06",
  "category": "bedrooms",
  "url": "/gallery/bedrooms-06.jpg",
  "thumbUrl": "/gallery/thumbs/bedrooms-06.jpg",
  "width": 1600,
  "height": 920,
  "sortOrder": 40
 },
 {
  "title": "Bedroom 07",
  "category": "bedrooms",
  "url": "/gallery/bedrooms-07.jpg",
  "thumbUrl": "/gallery/thumbs/bedrooms-07.jpg",
  "width": 1600,
  "height": 900,
  "sortOrder": 41
 },
 {
  "title": "Bedroom 08",
  "category": "bedrooms",
  "url": "/gallery/bedrooms-08.jpg",
  "thumbUrl": "/gallery/thumbs/bedrooms-08.jpg",
  "width": 1600,
  "height": 933,
  "sortOrder": 42
 },
 {
  "title": "Bedroom 09",
  "category": "bedrooms",
  "url": "/gallery/bedrooms-09.jpg",
  "thumbUrl": "/gallery/thumbs/bedrooms-09.jpg",
  "width": 1600,
  "height": 1086,
  "sortOrder": 43
 },
 {
  "title": "Bedroom 10",
  "category": "bedrooms",
  "url": "/gallery/bedrooms-10.jpg",
  "thumbUrl": "/gallery/thumbs/bedrooms-10.jpg",
  "width": 1600,
  "height": 1026,
  "sortOrder": 44
 },
 {
  "title": "Bedroom 11",
  "category": "bedrooms",
  "url": "/gallery/bedrooms-11.jpg",
  "thumbUrl": "/gallery/thumbs/bedrooms-11.jpg",
  "width": 1600,
  "height": 920,
  "sortOrder": 45
 },
 {
  "title": "Bedroom 12",
  "category": "bedrooms",
  "url": "/gallery/bedrooms-12.jpg",
  "thumbUrl": "/gallery/thumbs/bedrooms-12.jpg",
  "width": 1600,
  "height": 982,
  "sortOrder": 46
 },
 {
  "title": "Children's room 01",
  "category": "kids",
  "url": "/gallery/kids-01.jpg",
  "thumbUrl": "/gallery/thumbs/kids-01.jpg",
  "width": 1600,
  "height": 982,
  "sortOrder": 47
 },
 {
  "title": "Children's room 02",
  "category": "kids",
  "url": "/gallery/kids-02.jpg",
  "thumbUrl": "/gallery/thumbs/kids-02.jpg",
  "width": 1600,
  "height": 1511,
  "sortOrder": 48
 },
 {
  "title": "Children's room 03",
  "category": "kids",
  "url": "/gallery/kids-03.jpg",
  "thumbUrl": "/gallery/thumbs/kids-03.jpg",
  "width": 1600,
  "height": 920,
  "sortOrder": 49
 },
 {
  "title": "Children's room 04",
  "category": "kids",
  "url": "/gallery/kids-04.jpg",
  "thumbUrl": "/gallery/thumbs/kids-04.jpg",
  "width": 1600,
  "height": 920,
  "sortOrder": 50
 },
 {
  "title": "Children's room 05",
  "category": "kids",
  "url": "/gallery/kids-05.jpg",
  "thumbUrl": "/gallery/thumbs/kids-05.jpg",
  "width": 1600,
  "height": 920,
  "sortOrder": 51
 },
 {
  "title": "Pooja room 01",
  "category": "pooja",
  "url": "/gallery/pooja-01.jpg",
  "thumbUrl": "/gallery/thumbs/pooja-01.jpg",
  "width": 1446,
  "height": 1600,
  "sortOrder": 52
 },
 {
  "title": "Pooja room 02",
  "category": "pooja",
  "url": "/gallery/pooja-02.jpg",
  "thumbUrl": "/gallery/thumbs/pooja-02.jpg",
  "width": 1800,
  "height": 1650,
  "sortOrder": 53
 },
 {
  "title": "Pooja room 03",
  "category": "pooja",
  "url": "/gallery/pooja-03.jpg",
  "thumbUrl": "/gallery/thumbs/pooja-03.jpg",
  "width": 1600,
  "height": 960,
  "sortOrder": 54
 },
 {
  "title": "Pooja room 04",
  "category": "pooja",
  "url": "/gallery/pooja-04.jpg",
  "thumbUrl": "/gallery/thumbs/pooja-04.jpg",
  "width": 1600,
  "height": 1333,
  "sortOrder": 55
 },
 {
  "title": "Leisure space 01",
  "category": "leisure",
  "url": "/gallery/leisure-01.jpg",
  "thumbUrl": "/gallery/thumbs/leisure-01.jpg",
  "width": 1600,
  "height": 900,
  "sortOrder": 56
 },
 {
  "title": "Leisure space 02",
  "category": "leisure",
  "url": "/gallery/leisure-02.jpg",
  "thumbUrl": "/gallery/thumbs/leisure-02.jpg",
  "width": 1600,
  "height": 900,
  "sortOrder": 57
 },
 {
  "title": "Leisure space 03",
  "category": "leisure",
  "url": "/gallery/leisure-03.jpg",
  "thumbUrl": "/gallery/thumbs/leisure-03.jpg",
  "width": 1600,
  "height": 900,
  "sortOrder": 58
 },
 {
  "title": "Leisure space 04",
  "category": "leisure",
  "url": "/gallery/leisure-04.jpg",
  "thumbUrl": "/gallery/thumbs/leisure-04.jpg",
  "width": 1600,
  "height": 900,
  "sortOrder": 59
 },
 {
  "title": "Leisure space 05",
  "category": "leisure",
  "url": "/gallery/leisure-05.jpg",
  "thumbUrl": "/gallery/thumbs/leisure-05.jpg",
  "width": 1600,
  "height": 920,
  "sortOrder": 60
 },
 {
  "title": "Leisure space 06",
  "category": "leisure",
  "url": "/gallery/leisure-06.jpg",
  "thumbUrl": "/gallery/thumbs/leisure-06.jpg",
  "width": 1800,
  "height": 1035,
  "sortOrder": 61
 },
 {
  "title": "Leisure space 07",
  "category": "leisure",
  "url": "/gallery/leisure-07.jpg",
  "thumbUrl": "/gallery/thumbs/leisure-07.jpg",
  "width": 1600,
  "height": 920,
  "sortOrder": 62
 },
 {
  "title": "Interior detail 01",
  "category": "details",
  "url": "/gallery/details-01.jpg",
  "thumbUrl": "/gallery/thumbs/details-01.jpg",
  "width": 1600,
  "height": 1068,
  "sortOrder": 63
 },
 {
  "title": "Interior detail 02",
  "category": "details",
  "url": "/gallery/details-02.jpg",
  "thumbUrl": "/gallery/thumbs/details-02.jpg",
  "width": 1600,
  "height": 1026,
  "sortOrder": 64
 },
 {
  "title": "Interior detail 03",
  "category": "details",
  "url": "/gallery/details-03.jpg",
  "thumbUrl": "/gallery/thumbs/details-03.jpg",
  "width": 1600,
  "height": 1120,
  "sortOrder": 65
 },
 {
  "title": "Interior detail 04",
  "category": "details",
  "url": "/gallery/details-04.jpg",
  "thumbUrl": "/gallery/thumbs/details-04.jpg",
  "width": 1600,
  "height": 800,
  "sortOrder": 66
 },
 {
  "title": "Interior detail 05",
  "category": "details",
  "url": "/gallery/details-05.jpg",
  "thumbUrl": "/gallery/thumbs/details-05.jpg",
  "width": 1600,
  "height": 982,
  "sortOrder": 67
 }
]
