// All site content lives in lib/site-config.ts (text, projects, services) and
// lib/gallery-seed.ts (photos). Edit those files, rebuild, and redeploy.
import { siteConfig } from '@/lib/site-config'
import { gallerySeed, type GalleryItem } from '@/lib/gallery-seed'

export const STUDIO_VIDEO = 'https://www.youtube.com/embed/ltrkI5KjcP4'
export const SITE_URL = 'https://brukaandesigns.com'

/** Hide leftover "Add the detailed description…" placeholder copy. */
export function clean(text?: string | null): string {
  const t = (text ?? '').trim()
  return /^add (the|a|an)\b/i.test(t) ? '' : t
}

export type Settings = {
  firmName: string; tagline: string; description: string; logoUrl: string
  address: string; city: string; state: string; country: string
  phone: string; email: string; whatsapp: string
  mapsEmbedUrl: string; mapsDirectionsUrl: string
  businessHours: string; serviceAreas: string; studioVideoUrl: string
  social: { instagram: string; facebook: string; linkedin: string; youtube: string; pinterest: string }
}
export type PublicProject = {
  slug: string; title: string; location: string; year: string; type: string; status: string; area: string
  shortDescription: string; description: string; concept: string; coverImage: string; gallery: string[]
  videoUrl: string; mapsUrl: string
}
export type PublicService = { slug: string; title: string; summary: string; details: string }

export async function getSettings(): Promise<Settings> {
  const c = siteConfig
  return {
    firmName: c.firmName, tagline: c.tagline, description: c.description, logoUrl: c.logoUrl,
    address: c.address, city: c.city, state: c.state, country: c.country,
    phone: c.phone, email: c.email, whatsapp: c.whatsapp,
    mapsEmbedUrl: c.mapsEmbedUrl, mapsDirectionsUrl: c.mapsDirectionsUrl,
    businessHours: c.businessHours, serviceAreas: c.serviceAreas, studioVideoUrl: STUDIO_VIDEO,
    social: { ...c.social },
  }
}

export async function getProjects(): Promise<PublicProject[]> {
  return siteConfig.projects.map((p) => ({
    slug: p.slug, title: p.title, location: p.location, year: p.year, type: p.type, status: p.status, area: p.area,
    shortDescription: p.shortDescription, description: clean(p.description), concept: clean(p.concept),
    coverImage: p.coverImage, gallery: [...p.gallery], videoUrl: p.videoUrl, mapsUrl: p.mapsUrl,
  }))
}
export async function getProject(slug: string) {
  return (await getProjects()).find((p) => p.slug === slug) ?? null
}
export async function getServices(): Promise<PublicService[]> {
  return siteConfig.services.map((x) => ({ slug: x.slug, title: x.title, summary: x.summary, details: x.details }))
}
export async function getGallery(): Promise<GalleryItem[]> {
  return gallerySeed
}

export function youtubeEmbed(url?: string): string {
  if (!url) return ''
  try {
    if (url.includes('/embed/')) return url
    const u = new URL(url)
    const id = u.hostname.includes('youtu.be') ? u.pathname.slice(1) : u.searchParams.get('v')
    return id ? `https://www.youtube.com/embed/${id}` : ''
  } catch { return '' }
}
